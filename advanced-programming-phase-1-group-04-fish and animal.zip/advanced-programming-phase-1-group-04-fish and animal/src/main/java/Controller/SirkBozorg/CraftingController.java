package Controller.SirkBozorg;

import Model.Crafting.Craft;
import Model.Map.Coordinate;

public class CraftingController {
    public String showRecipe () {

        return "";
    }

    public void makeCraft (Craft craft) {

    }

    public void placeCraft (Craft craft, Coordinate coordinate) {

    }
}
