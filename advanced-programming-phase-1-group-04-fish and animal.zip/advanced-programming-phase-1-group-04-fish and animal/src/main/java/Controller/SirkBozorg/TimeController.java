package Controller.SirkBozorg;

import Model.Enum.Season;

public class TimeController {
    public void seasonChange (Season currentSeason) {
    }
    public void dayChange() {
    }
}
