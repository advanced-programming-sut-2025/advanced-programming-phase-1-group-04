package Controller.SirkBozorg;

public class WeatherController {
    public void lightning () {

    }
}
