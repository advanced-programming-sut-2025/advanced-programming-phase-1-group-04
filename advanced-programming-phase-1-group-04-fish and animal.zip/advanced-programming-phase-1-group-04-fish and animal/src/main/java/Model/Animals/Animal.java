package Model.Animals;

import Model.Item;

import java.util.ArrayList;

public class Animal {
    private boolean livesInBarn;
    private ArrayList<Item> products = new ArrayList<>();
}
