package Model.Animals;

public class AnimalProduct {
}
