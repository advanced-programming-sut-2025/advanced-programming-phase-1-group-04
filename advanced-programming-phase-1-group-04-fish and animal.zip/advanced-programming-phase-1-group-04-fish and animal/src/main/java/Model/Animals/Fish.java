package Model.Animals;

import Model.Enum.Season;

public class Fish {
    private FishType name;
    private int price;
    private Season season;
}
