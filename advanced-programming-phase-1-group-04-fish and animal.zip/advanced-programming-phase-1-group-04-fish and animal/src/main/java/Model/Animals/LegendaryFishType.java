package Model.Animals;

public enum LegendaryFishType {
    Legend,
    GlacierFish,
    Angler,
    CrimsonFish;
}
