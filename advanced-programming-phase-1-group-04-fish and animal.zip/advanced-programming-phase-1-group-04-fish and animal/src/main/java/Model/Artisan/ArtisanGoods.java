package Model.Artisan;

public enum ArtisanGoods {
    BeeHouse,
    CheesePress,
    Keg,
    Dehydrator,
    CharcoalKin,
    Loom,
    MayonnaiseMachine,
    OilMaker,
    PreservesJar,
    FishSmoker,
    Furnace;
}
