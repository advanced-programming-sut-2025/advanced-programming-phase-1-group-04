package Model.Cooking;

import Model.Item;

import java.util.ArrayList;

public class Food {
    private FoodType name;
    private ArrayList<Item> ingredients = new ArrayList<>();
    private int energy;
    //buff
    //source
    private int sellPrice;

}
