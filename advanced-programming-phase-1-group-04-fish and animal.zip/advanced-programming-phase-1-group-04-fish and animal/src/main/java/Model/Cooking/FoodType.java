package Model.Cooking;

public enum FoodType {
    MakiRoll,
    TripleShotEspresso,
    Cookie,
    hashBrowns,
    pancakes,
    fruitSalad,
    redPlate,
    bread,
    salmonDinner,
    vegetableMedley,
    farmersLunch,
    survivalBurger,
    dishOTheSea,
    seaFormPudding,
    minerStreet;
}
