package Model.Cooking;

import Model.Item;

import java.util.ArrayList;

public class Refrigerator {
    private ArrayList<Item> items = new ArrayList<>();

}
