package Model.Crafting;

import Model.Item;

import java.util.ArrayList;

public class Craft {
    private ArrayList<Item> ingredients = new ArrayList<>();
    //source
    private int sellPrice;
}
