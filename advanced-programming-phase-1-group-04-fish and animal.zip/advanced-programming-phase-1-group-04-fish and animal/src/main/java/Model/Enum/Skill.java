package Model.Enum;

public enum Skill {
    Farming,
    Mining,
    Foraging,
    Fishing;
}
