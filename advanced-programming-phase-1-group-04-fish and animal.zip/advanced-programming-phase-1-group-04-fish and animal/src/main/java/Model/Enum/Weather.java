package Model.Enum;

public enum Weather {
    Sunny,
    Rain,
    Storm,
    Snow;
}
