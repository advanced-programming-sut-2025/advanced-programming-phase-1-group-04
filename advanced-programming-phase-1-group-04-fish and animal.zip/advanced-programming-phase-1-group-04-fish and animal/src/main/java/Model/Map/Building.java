package Model.Map;

public class Building {
}
