package Model.Map;


public enum BuildingType {
    GreenHouse;
}
