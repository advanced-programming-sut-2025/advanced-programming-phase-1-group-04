package Model.Map;

public class Coordinate {
    int x;
    int y;
}
