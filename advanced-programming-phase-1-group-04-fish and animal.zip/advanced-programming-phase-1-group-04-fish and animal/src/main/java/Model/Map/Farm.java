package Model.Map;

public class Farm {

}
