package Model.Map;

import Model.Item;

import java.util.ArrayList;
import java.util.HashMap;

public class Map {
    ArrayList<Farm> farms = new ArrayList<>();
    HashMap<Coordinate, Building> places = new HashMap<>();
    HashMap<Coordinate, Item> objects = new HashMap<>();
}