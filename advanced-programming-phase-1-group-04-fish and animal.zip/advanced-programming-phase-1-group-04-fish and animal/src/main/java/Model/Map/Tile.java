package Model.Map;

public class Tile {
    //Map section in score doc
    //fields:
    //...
    //sikim
    Coordinate coordinate;

    public void setCoordinate(Coordinate coordinate) {
        this.coordinate = coordinate;
    }
}