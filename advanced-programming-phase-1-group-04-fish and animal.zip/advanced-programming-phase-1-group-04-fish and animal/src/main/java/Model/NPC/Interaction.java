package Model.NPC;

public enum Interaction {
    Gifting,
    Taking;
}
