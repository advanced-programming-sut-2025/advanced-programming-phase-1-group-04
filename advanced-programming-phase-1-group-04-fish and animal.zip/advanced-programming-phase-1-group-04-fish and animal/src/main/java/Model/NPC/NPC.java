package Model.NPC;

import Model.Item;
import Model.Map.Building;

import java.util.ArrayList;

public class NPC {
    private String name;
    private String job;
    private Building home;
    private ArrayList<Item> favorites = new ArrayList<>();
    private ArrayList<Quest> quests = new ArrayList<>();
}
