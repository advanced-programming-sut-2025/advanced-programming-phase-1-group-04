package Model.NPC;

public enum NPCType {
    Sebastien,
    Abigail,
    Harvey,
    Lia,
    Robin;
}
