package Model.NPC;

public class Quest {
}
