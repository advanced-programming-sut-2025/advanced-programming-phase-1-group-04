package Model.Products;

public enum ForagingCrops {
}
