package Model.Products;

public enum ForagingMinerals {
}
