package Model.Products;

public enum ForagingTrees {
}
