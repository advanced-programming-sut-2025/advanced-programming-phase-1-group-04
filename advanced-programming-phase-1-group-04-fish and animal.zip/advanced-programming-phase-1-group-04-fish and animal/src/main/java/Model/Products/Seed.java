package Model.Products;

import Model.Enum.Season;

public class Seed {
    private SeedType name;
    private Season season;

}
