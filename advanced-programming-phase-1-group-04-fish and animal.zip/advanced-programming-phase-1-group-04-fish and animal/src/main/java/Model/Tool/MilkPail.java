package Model.Tool;

public enum MilkPail {
    Starter (4);

    private final int energy;

    MilkPail(int energy) {
        this.energy = energy;
    }
}
