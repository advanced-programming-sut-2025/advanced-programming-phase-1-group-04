package Model.Tool;

public enum Scythe {
    Starter (2);

    private final int energy;

    Scythe(int energy) {
        this.energy = energy;
    }
}
