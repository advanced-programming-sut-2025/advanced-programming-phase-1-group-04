package Model.Tool;

public enum Shear {
    Starter (4);

    private final int energy;

    Shear(int energy) {
        this.energy = energy;
    }
}
