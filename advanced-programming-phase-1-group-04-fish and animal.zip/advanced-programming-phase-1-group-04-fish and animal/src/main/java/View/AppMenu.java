package View;

import java.util.Scanner;

public interface AppMenu {
    void check (Scanner scanner);
}
